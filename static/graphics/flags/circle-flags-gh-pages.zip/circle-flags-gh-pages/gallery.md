<link rel="stylesheet" type="text/css" href="gallery.css" />

<h1>Gallery</h1>

<div class="container">
  <div><img src="flags/ad.svg" width="96"/><p>Andorra (<code>ad</code>)</p></div>
  <div><img src="flags/ae.svg" width="96"/><p>United Arab Emirates (<code>ae</code>)</p></div>
  <div><img src="flags/af.svg" width="96"/><p>Afghanistan (<code>af</code>)</p></div>
  <div><img src="flags/afar.svg" width="96"/><p>Afar</p></div>
  <div><img src="flags/ag.svg" width="96"/><p>Antigua and Barbuda (<code>ag</code>)</p></div>
  <div><img src="flags/ai.svg" width="96"/><p>Anguilla (<code>ai</code>)</p></div>
  <div><img src="flags/al.svg" width="96"/><p>Albania (<code>al</code>)</p></div>
  <div><img src="flags/am.svg" width="96"/><p>Armenia (<code>am</code>)</p></div>
  <div><img src="flags/ao.svg" width="96"/><p>Angola (<code>ao</code>)</p></div>
  <div><img src="flags/aq.svg" width="96"/><p>Antarctica (<code>aq</code>)</p></div>
  <div><img src="flags/ar.svg" width="96"/><p>Argentina (<code>ar</code>)</p></div>
  <div><img src="flags/as.svg" width="96"/><p>American Samoa (<code>as</code>)</p></div>
  <div><img src="flags/at.svg" width="96"/><p>Austria (<code>at</code>)</p></div>
  <div><img src="flags/au.svg" width="96"/><p>Australia (<code>au</code>)</p></div>
  <div><img src="flags/au-aboriginal.svg" width="96"/><p>Australian Aboriginal</p></div>
  <div><img src="flags/aw.svg" width="96"/><p>Aruba (<code>aw</code>)</p></div>
  <div><img src="flags/ax.svg" width="96"/><p>Åland Islands (<code>ax</code>)</p></div>
  <div><img src="flags/az.svg" width="96"/><p>Azerbaijan (<code>az</code>)</p></div>
  <div><img src="flags/ba.svg" width="96"/><p>Bosnia and Herzegovina (<code>ba</code>)</p></div>
  <div><img src="flags/bb.svg" width="96"/><p>Barbados (<code>bb</code>)</p></div>
  <div><img src="flags/bd.svg" width="96"/><p>Bangladesh (<code>bd</code>)</p></div>
  <div><img src="flags/be.svg" width="96"/><p>Belgium (<code>be</code>)</p></div>
  <div><img src="flags/bf.svg" width="96"/><p>Burkina Faso (<code>bf</code>)</p></div>
  <div><img src="flags/bg.svg" width="96"/><p>Bulgaria (<code>bg</code>)</p></div>
  <div><img src="flags/bh.svg" width="96"/><p>Bahrain (<code>bh</code>)</p></div>
  <div><img src="flags/bi.svg" width="96"/><p>Burundi (<code>bi</code>)</p></div>
  <div><img src="flags/bj.svg" width="96"/><p>Benin (<code>bj</code>)</p></div>
  <div><img src="flags/bl.svg" width="96"/><p>Saint Barthélemy (<code>bl</code>)</p></div>
  <div><img src="flags/bm.svg" width="96"/><p>Bermuda (<code>bm</code>)</p></div>
  <div><img src="flags/bn.svg" width="96"/><p>Brunei (<code>bn</code>)</p></div>
  <div><img src="flags/bo.svg" width="96"/><p>Bolivia (<code>bo</code>)</p></div>
  <div><img src="flags/bq-bo.svg" width="96"/><p>Bonaire (<code>bq-bo</code>)</p></div>
  <div><img src="flags/bq-sa.svg" width="96"/><p>Saba (<code>bq-sa</code>)</p></div>
  <div><img src="flags/bq-se.svg" width="96"/><p>Sint Eustatius (<code>bq-se</code>)</p></div>
  <div><img src="flags/br.svg" width="96"/><p>Brazil (<code>br</code>)</p></div>
  <div><img src="flags/bs.svg" width="96"/><p>Bahamas (<code>bs</code>)</p></div>
  <div><img src="flags/bt.svg" width="96"/><p>Bhutan (<code>bt</code>)</p></div>
  <div><img src="flags/bv.svg" width="96"/><p>Bouvet Island (<code>bv</code>)</p></div>
  <div><img src="flags/bw.svg" width="96"/><p>Botswana (<code>bw</code>)</p></div>
  <div><img src="flags/by.svg" width="96"/><p>Belarus (<code>by</code>)</p></div>
  <div><img src="flags/bz.svg" width="96"/><p>Belize (<code>bz</code>)</p></div>
  <div><img src="flags/ca.svg" width="96"/><p>Canada (<code>ca</code>)</p></div>
  <div><img src="flags/ca-bc.svg" width="96"/><p>British Columbia (<code>ca-bc</code>)</p></div>
  <div><img src="flags/cc.svg" width="96"/><p>Cocos (Keeling) Islands (<code>cc</code>)</p></div>
  <div><img src="flags/cd.svg" width="96"/><p>Congo, Democratic Republic of the (<code>cd</code>)</p></div>
  <div><img src="flags/cf.svg" width="96"/><p>Central African Republic (<code>cf</code>)</p></div>
  <div><img src="flags/cg.svg" width="96"/><p>Congo (<code>cg</code>)</p></div>
  <div><img src="flags/ch.svg" width="96"/><p>Switzerland (<code>ch</code>)</p></div>
  <div><img src="flags/ch-gr.svg" width="96"/><p>Grisons (<code>ch-gr</code>)</p></div>
  <div><img src="flags/ci.svg" width="96"/><p>Ivory Coast (<code>ci</code>)</p></div>
  <div><img src="flags/ck.svg" width="96"/><p>Cook Islands (<code>ck</code>)</p></div>
  <div><img src="flags/cl.svg" width="96"/><p>Chile (<code>cl</code>)</p></div>
  <div><img src="flags/cm.svg" width="96"/><p>Cameroon (<code>cm</code>)</p></div>
  <div><img src="flags/cn.svg" width="96"/><p>China (<code>cn</code>)</p></div>
  <div><img src="flags/cn-xj.svg" width="96"/><p>Xinjiang (<code>cn-xj</code>)</p></div>
  <div><img src="flags/co.svg" width="96"/><p>Colombia (<code>co</code>)</p></div>
  <div><img src="flags/cr.svg" width="96"/><p>Costa Rica (<code>cr</code>)</p></div>
  <div><img src="flags/cu.svg" width="96"/><p>Cuba (<code>cu</code>)</p></div>
  <div><img src="flags/cv.svg" width="96"/><p>Cabo Verde (<code>cv</code>)</p></div>
  <div><img src="flags/cw.svg" width="96"/><p>Curaçao (<code>cw</code>)</p></div>
  <div><img src="flags/cx.svg" width="96"/><p>Christmas Island (<code>cx</code>)</p></div>
  <div><img src="flags/cy.svg" width="96"/><p>Cyprus (<code>cy</code>)</p></div>
  <div><img src="flags/cz.svg" width="96"/><p>Czechia (<code>cz</code>)</p></div>
  <div><img src="flags/de.svg" width="96"/><p>Germany (<code>de</code>)</p></div>
  <div><img src="flags/dj.svg" width="96"/><p>Djibouti (<code>dj</code>)</p></div>
  <div><img src="flags/dk.svg" width="96"/><p>Denmark (<code>dk</code>)</p></div>
  <div><img src="flags/dm.svg" width="96"/><p>Dominica (<code>dm</code>)</p></div>
  <div><img src="flags/do.svg" width="96"/><p>Dominican Republic (<code>do</code>)</p></div>
  <div><img src="flags/dz.svg" width="96"/><p>Algeria (<code>dz</code>)</p></div>
  <div><img src="flags/earth.svg" width="96"/><p>Earth</p></div>
  <div><img src="flags/east_african_federation.svg" width="96"/><p>East African Federation</p></div>
  <div><img src="flags/easter_island.svg" width="96"/><p>Easter Island</p></div>
  <div><img src="flags/ec.svg" width="96"/><p>Ecuador (<code>ec</code>)</p></div>
  <div><img src="flags/ec-w.svg" width="96"/><p>Galápagos (<code>ec-w</code>)</p></div>
  <div><img src="flags/ee.svg" width="96"/><p>Estonia (<code>ee</code>)</p></div>
  <div><img src="flags/eg.svg" width="96"/><p>Egypt (<code>eg</code>)</p></div>
  <div><img src="flags/eh.svg" width="96"/><p>Western Sahara (<code>eh</code>)</p></div>
  <div><img src="flags/er.svg" width="96"/><p>Eritrea (<code>er</code>)</p></div>
  <div><img src="flags/es.svg" width="96"/><p>Spain (<code>es</code>)</p></div>
  <div><img src="flags/es-variant.svg" width="96"/><p>Spain</p></div>
  <div><img src="flags/es-ar.svg" width="96"/><p>Aragon (<code>es-ar</code>)</p></div>
  <div><img src="flags/es-ce.svg" width="96"/><p>Ceuta (<code>es</code>)</p></div>
  <div><img src="flags/es-cn.svg" width="96"/><p>Canary Islands (<code>es-cn</code>)</p></div>
  <div><img src="flags/es-ct.svg" width="96"/><p>Catalonia (<code>es-ct</code>)</p></div>
  <div><img src="flags/es-ga.svg" width="96"/><p>Galicia (<code>es-ga</code>)</p></div>
  <div><img src="flags/es-ib.svg" width="96"/><p>Balearic Islands (<code>es-ib</code>)</p></div>
  <div><img src="flags/es-ml.svg" width="96"/><p>Melilla (<code>es-ml</code>)</p></div>
  <div><img src="flags/es-pv.svg" width="96"/><p>Basque Country (<code>es-pv</code>)</p></div>
  <div><img src="flags/et.svg" width="96"/><p>Ethiopia (<code>et</code>)</p></div>
  <div><img src="flags/et-or.svg" width="96"/><p>Oromia (<code>et-or</code>)</p></div>
  <div><img src="flags/et-ti.svg" width="96"/><p>Tigray Region (<code>et-ti</code>)</p></div>
  <div><img src="flags/european_union.svg" width="96"/><p>European Union (<code>eu</code>)</p></div>
  <div><img src="flags/ewe.svg" width="96"/><p>Ewe</p></div>
  <div><img src="flags/fi.svg" width="96"/><p>Finland (<code>fi</code>)</p></div>
  <div><img src="flags/fj.svg" width="96"/><p>Fiji (<code>fj</code>)</p></div>
  <div><img src="flags/fk.svg" width="96"/><p>Falkland Islands (Malvinas) (<code>fk</code>)</p></div>
  <div><img src="flags/fm.svg" width="96"/><p>Micronesia (<code>fm</code>)</p></div>
  <div><img src="flags/fo.svg" width="96"/><p>Faroe Islands (<code>fo</code>)</p></div>
  <div><img src="flags/fr.svg" width="96"/><p>France (<code>fr</code>)</p></div>
  <div><img src="flags/fr-20r.svg" width="96"/><p>Corsica (<code>fr-20r</code>)</p></div>
  <div><img src="flags/fr-bre.svg" width="96"/><p>Brittany (<code>fr-bre</code>)</p></div>
  <div><img src="flags/fr-cp.svg" width="96"/><p>Clipperton Island (<code>fr-cp</code>)</p></div>
  <div><img src="flags/ga.svg" width="96"/><p>Gabon (<code>ga</code>)</p></div>
  <div><img src="flags/gb.svg" width="96"/><p>United Kingdom (<code>gb</code>)</p></div>
  <div><img src="flags/gb-con.svg" width="96"/><p>Cornwall (<code>gb-con</code>)</p></div>
  <div><img src="flags/gb-eng.svg" width="96"/><p>England (<code>gb-eng</code>)</p></div>
  <div><img src="flags/gb-nir.svg" width="96"/><p>Northern Ireland (<code>gb-nir</code>)</p></div>
  <div><img src="flags/gb-ork.svg" width="96"/><p>Orkney (<code>gb-ork</code>)</p></div>
  <div><img src="flags/gb-sct.svg" width="96"/><p>Scotland (<code>gb-sct</code>)</p></div>
  <div><img src="flags/gb-wls.svg" width="96"/><p>Wales (<code>gb-wls</code>)</p></div>
  <div><img src="flags/gd.svg" width="96"/><p>Grenada (<code>gd</code>)</p></div>
  <div><img src="flags/ge.svg" width="96"/><p>Georgia (<code>ge</code>)</p></div>
  <div><img src="flags/ge-ab.svg" width="96"/><p>Abkhazia (<code>ge-ab</code>)</p></div>
  <div><img src="flags/gf.svg" width="96"/><p>French Guiana (<code>gf</code>)</p></div>
  <div><img src="flags/gg.svg" width="96"/><p>Guernsey (<code>gg</code>)</p></div>
  <div><img src="flags/gh.svg" width="96"/><p>Ghana (<code>gh</code>)</p></div>
  <div><img src="flags/gi.svg" width="96"/><p>Gibraltar (<code>gi</code>)</p></div>
  <div><img src="flags/gl.svg" width="96"/><p>Greenland (<code>gl</code>)</p></div>
  <div><img src="flags/gm.svg" width="96"/><p>Gambia (<code>gm</code>)</p></div>
  <div><img src="flags/gn.svg" width="96"/><p>Guinea (<code>gn</code>)</p></div>
  <div><img src="flags/gp.svg" width="96"/><p>Guadeloupe (<code>gp</code>)</p></div>
  <div><img src="flags/gq.svg" width="96"/><p>Equatorial Guinea (<code>gq</code>)</p></div>
  <div><img src="flags/gr.svg" width="96"/><p>Greece (<code>gr</code>)</p></div>
  <div><img src="flags/gs.svg" width="96"/><p>South Georgia and the South Sandwich Islands (<code>gs</code>)</p></div>
  <div><img src="flags/gt.svg" width="96"/><p>Guatemala (<code>gt</code>)</p></div>
  <div><img src="flags/gu.svg" width="96"/><p>Guam (<code>gu</code>)</p></div>
  <div><img src="flags/guarani.svg" width="96"/><p>Guarani</p></div>
  <div><img src="flags/gw.svg" width="96"/><p>Guinea-Bissau (<code>gw</code>)</p></div>
  <div><img src="flags/gy.svg" width="96"/><p>Guyana (<code>gy</code>)</p></div>
  <div><img src="flags/hausa.svg" width="96"/><p>Hausa</p></div>
  <div><img src="flags/hk.svg" width="96"/><p>Hong Kong (<code>hk</code>)</p></div>
  <div><img src="flags/hmong.svg" width="96"/><p>Hmong</p></div>
  <div><img src="flags/hm.svg" width="96"/><p>Heard Island and McDonald Islands (<code>hm</code>)</p></div>
  <div><img src="flags/hn.svg" width="96"/><p>Honduras (<code>hn</code>)</p></div>
  <div><img src="flags/hr.svg" width="96"/><p>Croatia (<code>hr</code>)</p></div>
  <div><img src="flags/ht.svg" width="96"/><p>Haiti (<code>ht</code>)</p></div>
  <div><img src="flags/hu.svg" width="96"/><p>Hungary (<code>hu</code>)</p></div>
  <div><img src="flags/id.svg" width="96"/><p>Indonesia (<code>id</code>)</p></div>
  <div><img src="flags/id-jb.svg" width="96"/><p>West Java (<code>id-jb</code>)</p></div>
  <div><img src="flags/id-jt.svg" width="96"/><p>Central Java (<code>id-jt</code>)</p></div>
  <div><img src="flags/ie.svg" width="96"/><p>Ireland (<code>ie</code>)</p></div>
  <div><img src="flags/il.svg" width="96"/><p>Israel (<code>il</code>)</p></div>
  <div><img src="flags/im.svg" width="96"/><p>Isle of Man (<code>im</code>)</p></div>
  <div><img src="flags/in.svg" width="96"/><p>India (<code>in</code>)</p></div>
  <div><img src="flags/in-as.svg" width="96"/><p>Assam (<code>in-as</code>)</p></div>
  <div><img src="flags/in-gj.svg" width="96"/><p>Gujarat (<code>in-gj</code>)</p></div>
  <div><img src="flags/in-ka.svg" width="96"/><p>Karnataka (<code>in-ka</code>)</p></div>
  <div><img src="flags/in-or.svg" width="96"/><p>Odisha (<code>in-or</code>)</p></div>
  <div><img src="flags/in-tn.svg" width="96"/><p>Tamil Nadu (<code>in-tn</code>)</p></div>
  <div><img src="flags/io.svg" width="96"/><p>British Indian Ocean Territory (<code>io</code>)</p></div>
  <div><img src="flags/iq.svg" width="96"/><p>Iraq (<code>iq</code>)</p></div>
  <div><img src="flags/ir.svg" width="96"/><p>Iran (<code>ir</code>)</p></div>
  <div><img src="flags/is.svg" width="96"/><p>Iceland (<code>is</code>)</p></div>
  <div><img src="flags/it.svg" width="96"/><p>Italy (<code>it</code>)</p></div>
  <div><img src="flags/it-23.svg" width="96"/><p>Aosta Valley (<code>it-23</code>)</p></div>
  <div><img src="flags/it-82.svg" width="96"/><p>Sicily (<code>it-82</code>)</p></div>
  <div><img src="flags/it-88.svg" width="96"/><p>Sardinia (<code>it-88</code>)</p></div>
  <div><img src="flags/je.svg" width="96"/><p>Jersey (<code>je</code>)</p></div>
  <div><img src="flags/jm.svg" width="96"/><p>Jamaica (<code>jm</code>)</p></div>
  <div><img src="flags/jo.svg" width="96"/><p>Jordan (<code>jo</code>)</p></div>
  <div><img src="flags/jp.svg" width="96"/><p>Japan (<code>jp</code>)</p></div>
  <div><img src="flags/kanuri.svg" width="96"/><p>Kanuri</p></div>
  <div><img src="flags/ke.svg" width="96"/><p>Kenya (<code>ke</code>)</p></div>
  <div><img src="flags/kg.svg" width="96"/><p>Kyrgyzstan (<code>kg</code>)</p></div>
  <div><img src="flags/kh.svg" width="96"/><p>Cambodia (<code>kh</code>)</p></div>
  <div><img src="flags/ki.svg" width="96"/><p>Kiribati (<code>ki</code>)</p></div>
  <div><img src="flags/kikuyu.svg" width="96"/><p>Kikuyu</p></div>
  <div><img src="flags/km.svg" width="96"/><p>Comoros (<code>km</code>)</p></div>
  <div><img src="flags/kn.svg" width="96"/><p>Saint Kitts and Nevis (<code>kn</code>)</p></div>
  <div><img src="flags/kongo.svg" width="96"/><p>Kongo</p></div>
  <div><img src="flags/kp.svg" width="96"/><p>North Korea (<code>kp</code>)</p></div>
  <div><img src="flags/kr.svg" width="96"/><p>South Korea (<code>kr</code>)</p></div>
  <div><img src="flags/kurdistan.svg" width="96"/><p>Kurdistan</p></div>
  <div><img src="flags/kw.svg" width="96"/><p>Kuwait (<code>kw</code>)</p></div>
  <div><img src="flags/ky.svg" width="96"/><p>Cayman Islands (<code>ky</code>)</p></div>
  <div><img src="flags/kz.svg" width="96"/><p>Kazakhstan (<code>kz</code>)</p></div>
  <div><img src="flags/la.svg" width="96"/><p>Laos (<code>la</code>)</p></div>
  <div><img src="flags/lb.svg" width="96"/><p>Lebanon (<code>lb</code>)</p></div>
  <div><img src="flags/lc.svg" width="96"/><p>Saint Lucia (<code>lc</code>)</p></div>
  <div><img src="flags/li.svg" width="96"/><p>Liechtenstein (<code>li</code>)</p></div>
  <div><img src="flags/lk.svg" width="96"/><p>Sri Lanka (<code>lk</code>)</p></div>
  <div><img src="flags/lr.svg" width="96"/><p>Liberia (<code>lr</code>)</p></div>
  <div><img src="flags/ls.svg" width="96"/><p>Lesotho (<code>ls</code>)</p></div>
  <div><img src="flags/lt.svg" width="96"/><p>Lithuania (<code>lt</code>)</p></div>
  <div><img src="flags/lu.svg" width="96"/><p>Luxembourg (<code>lu</code>)</p></div>
  <div><img src="flags/lv.svg" width="96"/><p>Latvia (<code>lv</code>)</p></div>
  <div><img src="flags/ly.svg" width="96"/><p>Libya (<code>ly</code>)</p></div>
  <div><img src="flags/ma.svg" width="96"/><p>Morocco (<code>ma</code>)</p></div>
  <div><img src="flags/malayali.svg" width="96"/><p>Malayali</p></div>
  <div><img src="flags/maori.svg" width="96"/><p>Maori</p></div>
  <div><img src="flags/mc.svg" width="96"/><p>Monaco (<code>mc</code>)</p></div>
  <div><img src="flags/md.svg" width="96"/><p>Moldova (<code>md</code>)</p></div>
  <div><img src="flags/me.svg" width="96"/><p>Montenegro (<code>me</code>)</p></div>
  <div><img src="flags/mf.svg" width="96"/><p>Saint-Martin (<code>mf</code>)</p></div>
  <div><img src="flags/mg.svg" width="96"/><p>Madagascar (<code>mg</code>)</p></div>
  <div><img src="flags/mh.svg" width="96"/><p>Marshall Islands (<code>mh</code>)</p></div>
  <div><img src="flags/mk.svg" width="96"/><p>North Macedonia (<code>mk</code>)</p></div>
  <div><img src="flags/ml.svg" width="96"/><p>Mali (<code>ml</code>)</p></div>
  <div><img src="flags/mm.svg" width="96"/><p>Myanmar (<code>mm</code>)</p></div>
  <div><img src="flags/mn.svg" width="96"/><p>Mongolia (<code>mn</code>)</p></div>
  <div><img src="flags/mo.svg" width="96"/><p>Macao (<code>mo</code>)</p></div>
  <div><img src="flags/mp.svg" width="96"/><p>Northern Mariana Islands (<code>mp</code>)</p></div>
  <div><img src="flags/mq.svg" width="96"/><p>Martinique (<code>mq</code>)</p></div>
  <div><img src="flags/mr.svg" width="96"/><p>Mauritania (<code>mr</code>)</p></div>
  <div><img src="flags/ms.svg" width="96"/><p>Montserrat (<code>ms</code>)</p></div>
  <div><img src="flags/mt.svg" width="96"/><p>Malta (<code>mt</code>)</p></div>
  <div><img src="flags/mu.svg" width="96"/><p>Mauritius (<code>mu</code>)</p></div>
  <div><img src="flags/mv.svg" width="96"/><p>Maldives (<code>mv</code>)</p></div>
  <div><img src="flags/mw.svg" width="96"/><p>Malawi (<code>mw</code>)</p></div>
  <div><img src="flags/mx.svg" width="96"/><p>Mexico (<code>mx</code>)</p></div>
  <div><img src="flags/my.svg" width="96"/><p>Malaysia (<code>my</code>)</p></div>
  <div><img src="flags/mz.svg" width="96"/><p>Mozambique (<code>mz</code>)</p></div>
  <div><img src="flags/na.svg" width="96"/><p>Namibia (<code>na</code>)</p></div>
  <div><img src="flags/nc.svg" width="96"/><p>New Caledonia (<code>nc</code>)</p></div>
  <div><img src="flags/nato.svg" width="96"/><p>NATO</p></div>
  <div><img src="flags/ne.svg" width="96"/><p>Niger (<code>ne</code>)</p></div>
  <div><img src="flags/nf.svg" width="96"/><p>Norfolk Island (<code>nf</code>)</p></div>
  <div><img src="flags/ng.svg" width="96"/><p>Nigeria (<code>ng</code>)</p></div>
  <div><img src="flags/ni.svg" width="96"/><p>Nicaragua (<code>ni</code>)</p></div>
  <div><img src="flags/nl.svg" width="96"/><p>Netherlands (<code>nl</code>)</p></div>
  <div><img src="flags/nl-fr.svg" width="96"/><p>Friesland (<code>nl-fr</code>)</p></div>
  <div><img src="flags/no.svg" width="96"/><p>Norway (<code>no</code>)</p></div>
  <div><img src="flags/northern_cyprus.svg" width="96"/><p>Northern Cyprus</p></div>
  <div><img src="flags/np.svg" width="96"/><p>Nepal (<code>np</code>)</p></div>
  <div><img src="flags/nr.svg" width="96"/><p>Nauru (<code>nr</code>)</p></div>
  <div><img src="flags/nu.svg" width="96"/><p>Niue (<code>nu</code>)</p></div>
  <div><img src="flags/nz.svg" width="96"/><p>New Zealand (<code>nz</code>)</p></div>
  <div><img src="flags/occitania.svg" width="96"/><p>Occitania</p></div>
  <div><img src="flags/olympics.svg" width="96"/><p>Olympics</p></div>
  <div><img src="flags/om.svg" width="96"/><p>Oman (<code>om</code>)</p></div>
  <div><img src="flags/otomi.svg" width="96"/><p>Otomi</p></div>
  <div><img src="flags/pa.svg" width="96"/><p>Panama (<code>pa</code>)</p></div>
  <div><img src="flags/pe.svg" width="96"/><p>Peru (<code>pe</code>)</p></div>
  <div><img src="flags/pf.svg" width="96"/><p>French Polynesia (<code>pf</code>)</p></div>
  <div><img src="flags/pg.svg" width="96"/><p>Papua New Guinea (<code>pg</code>)</p></div>
  <div><img src="flags/ph.svg" width="96"/><p>Philippines (<code>ph</code>)</p></div>
  <div><img src="flags/pk.svg" width="96"/><p>Pakistan (<code>pk</code>)</p></div>
  <div><img src="flags/pk-jk.svg" width="96"/><p>Azad Kashmir (<code>pk-jk</code>)</p></div>
  <div><img src="flags/pk-sd.svg" width="96"/><p>Sindh (<code>pk-sd</code>)</p></div>
  <div><img src="flags/pl.svg" width="96"/><p>Poland (<code>pl</code>)</p></div>
  <div><img src="flags/pm.svg" width="96"/><p>Saint Pierre and Miquelon (<code>pm</code>)</p></div>
  <div><img src="flags/pn.svg" width="96"/><p>Pitcairn Islands (<code>pn</code>)</p></div>
  <div><img src="flags/pr.svg" width="96"/><p>Puerto Rico (<code>pr</code>)</p></div>
  <div><img src="flags/ps.svg" width="96"/><p>Palestine (<code>ps</code>)</p></div>
  <div><img src="flags/pt-20.svg" width="96"/><p>Azores (<code>pt-20</code>)</p></div>
  <div><img src="flags/pt-30.svg" width="96"/><p>Madeira (<code>pt-30</code>)</p></div>
  <div><img src="flags/pt.svg" width="96"/><p>Portugal (<code>pt</code>)</p></div>
  <div><img src="flags/pw.svg" width="96"/><p>Palau (<code>pw</code>)</p></div>
  <div><img src="flags/py.svg" width="96"/><p>Paraguay (<code>py</code>)</p></div>
  <div><img src="flags/qa.svg" width="96"/><p>Qatar (<code>qa</code>)</p></div>
  <div><img src="flags/quechua.svg" width="96"/><p>Quechua</p></div>
  <div><img src="flags/re.svg" width="96"/><p>Réunion (<code>re</code>)</p></div>
  <div><img src="flags/ro.svg" width="96"/><p>Romania (<code>ro</code>)</p></div>
  <div><img src="flags/rs.svg" width="96"/><p>Serbia (<code>rs</code>)</p></div>
  <div><img src="flags/ru.svg" width="96"/><p>Russia (<code>ru</code>)</p></div>
  <div><img src="flags/ru-ba.svg" width="96"/><p>Bashkortostan (<code>ru-ba</code>)</p></div>
  <div><img src="flags/ru-ce.svg" width="96"/><p>Chechnya (<code>ru-ce</code>)</p></div>
  <div><img src="flags/ru-cu.svg" width="96"/><p>Chuvashia (<code>ru-cu</code>)</p></div>
  <div><img src="flags/ru-da.svg" width="96"/><p>Dagestan (<code>ru-da</code>)</p></div>
  <div><img src="flags/ru-ko.svg" width="96"/><p>Komi Republic (<code>ru-ko</code>)</p></div>
  <div><img src="flags/ru-ta.svg" width="96"/><p>Tatarstan (<code>ru-ta</code>)</p></div>
  <div><img src="flags/ru-ud.svg" width="96"/><p>Udmurtia (<code>ru-ud</code>)</p></div>
  <div><img src="flags/rw.svg" width="96"/><p>Rwanda (<code>rw</code>)</p></div>
  <div><img src="flags/sa.svg" width="96"/><p>Saudi Arabia (<code>sa</code>)</p></div>
  <div><img src="flags/sami.svg" width="96"/><p>Sami</p></div>
  <div><img src="flags/sb.svg" width="96"/><p>Solomon Islands (<code>sb</code>)</p></div>
  <div><img src="flags/sc.svg" width="96"/><p>Seychelles (<code>sc</code>)</p></div>
  <div><img src="flags/sd.svg" width="96"/><p>Sudan (<code>sd</code>)</p></div>
  <div><img src="flags/se.svg" width="96"/><p>Sweden (<code>se</code>)</p></div>
  <div><img src="flags/sg.svg" width="96"/><p>Singapore (<code>sg</code>)</p></div>
  <div><img src="flags/sh-ac.svg" width="96"/><p>Ascension Island (<code>sh-ac</code>)</p></div>
  <div><img src="flags/sh-hl.svg" width="96"/><p>Saint Helena (<code>sh-hl</code>)</p></div>
  <div><img src="flags/sh-ta.svg" width="96"/><p>Tristan da Cunha (<code>sh-ta</code>)</p></div>
  <div><img src="flags/si.svg" width="96"/><p>Slovenia (<code>si</code>)</p></div>
  <div><img src="flags/sj.svg" width="96"/><p>Svalbard and Jan Mayen (<code>sj</code>)</p></div>
  <div><img src="flags/sk.svg" width="96"/><p>Slovakia (<code>sk</code>)</p></div>
  <div><img src="flags/sl.svg" width="96"/><p>Sierra Leone (<code>sl</code>)</p></div>
  <div><img src="flags/sm.svg" width="96"/><p>San Marino (<code>sm</code>)</p></div>
  <div><img src="flags/sn.svg" width="96"/><p>Senegal (<code>sn</code>)</p></div>
  <div><img src="flags/so.svg" width="96"/><p>Somalia (<code>so</code>)</p></div>
  <div><img src="flags/somaliland.svg" width="96"/><p>Somaliland</p></div>
  <div><img src="flags/south_ossetia.svg" width="96"/><p>South Ossetia</p></div>
  <div><img src="flags/soviet_union.svg" width="96"/><p>Soviet Union (<code>su</code>)</p></div>
  <div><img src="flags/sr.svg" width="96"/><p>Suriname (<code>sr</code>)</p></div>
  <div><img src="flags/ss.svg" width="96"/><p>South Sudan (<code>ss</code>)</p></div>
  <div><img src="flags/st.svg" width="96"/><p>São Tomé and Príncipe (<code>st</code>)</p></div>
  <div><img src="flags/sv.svg" width="96"/><p>El Salvador (<code>sv</code>)</p></div>
  <div><img src="flags/sx.svg" width="96"/><p>Sint Maarten (<code>sx</code>)</p></div>
  <div><img src="flags/sy.svg" width="96"/><p>Syria (<code>sy</code>)</p></div>
  <div><img src="flags/sz.svg" width="96"/><p>Eswatini (<code>sz</code>)</p></div>
  <div><img src="flags/tc.svg" width="96"/><p>Turks and Caicos Islands (<code>tc</code>)</p></div>
  <div><img src="flags/td.svg" width="96"/><p>Chad (<code>td</code>)</p></div>
  <div><img src="flags/tf.svg" width="96"/><p>French Southern Territories (<code>tf</code>)</p></div>
  <div><img src="flags/tg.svg" width="96"/><p>Togo (<code>tg</code>)</p></div>
  <div><img src="flags/th.svg" width="96"/><p>Thailand (<code>th</code>)</p></div>
  <div><img src="flags/tibet.svg" width="96"/><p>Tibet</p></div>
  <div><img src="flags/tj.svg" width="96"/><p>Tajikistan (<code>tj</code>)</p></div>
  <div><img src="flags/tk.svg" width="96"/><p>Tokelau (<code>tk</code>)</p></div>
  <div><img src="flags/tl.svg" width="96"/><p>Timor-Leste (<code>tl</code>)</p></div>
  <div><img src="flags/tm.svg" width="96"/><p>Turkmenistan (<code>tm</code>)</p></div>
  <div><img src="flags/tn.svg" width="96"/><p>Tunisia (<code>tn</code>)</p></div>
  <div><img src="flags/to.svg" width="96"/><p>Tonga (<code>to</code>)</p></div>
  <div><img src="flags/torres_strait_islands.svg" width="96"/><p>Torres Strait Islands</p></div>
  <div><img src="flags/tr.svg" width="96"/><p>Turkey (<code>tr</code>)</p></div>
  <div><img src="flags/transnistria.svg" width="96"/><p>Transnistria</p></div>
  <div><img src="flags/tt.svg" width="96"/><p>Trinidad and Tobago (<code>tt</code>)</p></div>
  <div><img src="flags/tv.svg" width="96"/><p>Tuvalu (<code>tv</code>)</p></div>
  <div><img src="flags/tw.svg" width="96"/><p>Taiwan (<code>tw</code>)</p></div>
  <div><img src="flags/tz.svg" width="96"/><p>Tanzania (<code>tz</code>)</p></div>
  <div><img src="flags/ua.svg" width="96"/><p>Ukraine (<code>ua</code>)</p></div>
  <div><img src="flags/ug.svg" width="96"/><p>Uganda (<code>ug</code>)</p></div>
  <div><img src="flags/united_nations.svg" width="96"/><p>United Nations (<code>un</code>)</p></div>
  <div><img src="flags/us.svg" width="96"/><p>United States of America (<code>us</code>)</p></div>
  <div><img src="flags/us-hi.svg" width="96"/><p>Hawaii (<code>us-hi</code>)</p></div>
  <div><img src="flags/um.svg" width="96"/><p>United States Minor Outlying Islands (<code>um</code>)</p></div>
  <div><img src="flags/uy.svg" width="96"/><p>Uruguay (<code>uy</code>)</p></div>
  <div><img src="flags/uz.svg" width="96"/><p>Uzbekistan (<code>uz</code>)</p></div>
  <div><img src="flags/va.svg" width="96"/><p>Holy See (Vatican) (<code>va</code>)</p></div>
  <div><img src="flags/vc.svg" width="96"/><p>Saint Vincent and the Grenadines (<code>vc</code>)</p></div>
  <div><img src="flags/ve.svg" width="96"/><p>Venezuela (<code>ve</code>)</p></div>
  <div><img src="flags/vg.svg" width="96"/><p>Virgin Islands (British) (<code>vg</code>)</p></div>
  <div><img src="flags/vi.svg" width="96"/><p>Virgin Islands (U.S.) (<code>vi</code>)</p></div>
  <div><img src="flags/vn.svg" width="96"/><p>Vietnam (<code>vn</code>)</p></div>
  <div><img src="flags/vu.svg" width="96"/><p>Vanuatu (<code>vu</code>)</p></div>
  <div><img src="flags/wf.svg" width="96"/><p>Wallis and Futuna (<code>wf</code>)</p></div>
  <div><img src="flags/wiphala.svg" width="96"/><p>Wiphala</p></div>
  <div><img src="flags/ws.svg" width="96"/><p>Samoa (<code>ws</code>)</p></div>
  <div><img src="flags/xk.svg" width="96"/><p>Kosovo (<code>xk</code>)</p></div>
  <div><img src="flags/xx.svg" width="96"/><p>&lt;Placeholder&gt;</p></div>
  <div><img src="flags/ye.svg" width="96"/><p>Yemen (<code>ye</code>)</p></div>
  <div><img src="flags/yorubaland.svg" width="96"/><p>Yorubaland</p></div>
  <div><img src="flags/yt.svg" width="96"/><p>Mayotte (<code>yt</code>)</p></div>
  <div><img src="flags/za.svg" width="96"/><p>South Africa (<code>za</code>)</p></div>
  <div><img src="flags/zm.svg" width="96"/><p>Zambia (<code>zm</code>)</p></div>
  <div><img src="flags/zw.svg" width="96"/><p>Zimbabwe (<code>zw</code>)</p></div>
</div>
